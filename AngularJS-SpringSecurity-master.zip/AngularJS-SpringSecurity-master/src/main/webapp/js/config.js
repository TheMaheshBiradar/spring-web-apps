
var exampleAppConfig = {
	/* When set to false a query parameter is used to pass on the auth token.
	 * This might be desirable if headers don't work correctly in some
	 * environments and is still secure when using https. */
	useAuthTokenHeader: true,
	//service : 'http://localhost:8080/angular-rest-springsecurity/'
	service : 'http://localhost:8080/AngularJS-SpringSecurity/'
		
};