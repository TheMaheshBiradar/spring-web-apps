package net.dontdrinkandroot.example.angularrestspringsecurity.entity;

import java.io.Serializable;


public interface Entity extends Serializable
{

}