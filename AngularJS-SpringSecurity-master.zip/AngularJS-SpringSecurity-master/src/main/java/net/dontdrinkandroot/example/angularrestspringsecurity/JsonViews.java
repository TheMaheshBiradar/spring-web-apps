package net.dontdrinkandroot.example.angularrestspringsecurity;

public class JsonViews
{

	public static class User
	{
	}

	public static class Admin extends User
	{
	}

}
