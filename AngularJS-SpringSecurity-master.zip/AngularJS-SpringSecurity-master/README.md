# AngularJS-SpringSecurity
This is a fork from https://github.com/philipsorst/angular-rest-springsecurity but with some changes.
The client layer was decoupled from the services layer (to deploy in different domais, inclusive Mobile Apps). The datasource was changed to work with PostgreSql and the NewsResource was changed to acept PUT for update.
