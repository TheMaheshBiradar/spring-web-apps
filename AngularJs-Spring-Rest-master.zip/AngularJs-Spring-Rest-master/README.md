AngularJs-Spring-Rest
=====================

Learn Angular

Steps to Setup the Application
