package com.oodd.spring.singletableinheritance.dto;

public class TCPDto extends ProtocolDto {

}
