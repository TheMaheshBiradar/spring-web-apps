package com.oodd.spring.singletableinheritance.dto;

public class SNMPDto extends ProtocolDto {

}
