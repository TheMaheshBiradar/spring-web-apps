Spring Hibernate TDD REST Agile Java Book
=========================================
The repository is the sample code of a Spring and Hibernate book. The author and his team has put lot of effort in putting together this vast useful code. If you find the information useful, do buy the book. 

Title of the book: Spring, Hibernate, Data Modeling, REST and TDD: Agile Java Design and Development

Blog: http://amritendude.blogspot.in/2014/06/new-book-on-spring-4-and-hibernate-4.html

Availability: Available on all Amazon sites

Amritendu De
(amritendu_de@yahoo.com)
