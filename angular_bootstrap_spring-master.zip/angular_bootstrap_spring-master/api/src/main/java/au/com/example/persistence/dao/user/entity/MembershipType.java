package au.com.example.persistence.dao.user.entity;

public enum MembershipType {
    ADMIN,

    CASUAL,

    STUDENT,

    TEACHER_LITE,

    TEACHER_PROFESSIONAL;
}
