package au.com.example.service.user;

import org.springframework.security.provisioning.UserDetailsManager;

public interface UserService extends UserDetailsManager {

}
