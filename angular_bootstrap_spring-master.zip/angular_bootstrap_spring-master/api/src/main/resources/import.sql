insert into user (account_non_expired, account_non_locked, credentials_non_expired, enabled, first_name, last_name, alias, password, email) values (true, true, true, true, 'Test', 'User', 'Test User', '$2a$10$xT/t.6abkjaRpAkNOrt43OD9Cn2aaS3vgxQsnLtEN7mOi6RpACvbm', 'user@tester.com.au');

insert into Customer (first_name, last_name) values ('Foo', 'Bar');
insert into Customer (first_name, last_name) values ('Jim', 'Sunny');
insert into Customer (first_name, last_name) values ('Peter', 'Prone');
insert into Customer (first_name, last_name) values ('Sam', 'Sully');