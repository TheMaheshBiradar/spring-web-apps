'use strict';

angular.module('app', ['ngRoute', 'ngMessages', 'ngAria', 'xeditable', 'app.constants', 'app.directives', 'app.controllers', 'app.services']);