'use strict';

angular.module('app.constants').constant('storageConstant', {
    USER: 'user',
    AUTH_TOKEN: 'authToken'
});