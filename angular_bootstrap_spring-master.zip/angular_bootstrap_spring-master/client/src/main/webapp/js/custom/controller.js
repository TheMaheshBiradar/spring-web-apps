'use strict';

angular.module('app.controllers', ['app.services']);