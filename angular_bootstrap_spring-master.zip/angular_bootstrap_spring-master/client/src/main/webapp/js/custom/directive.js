'use strict';

angular.module('app.directives', ['app.services']);
