'use strict';

angular.module('app.constants', []);