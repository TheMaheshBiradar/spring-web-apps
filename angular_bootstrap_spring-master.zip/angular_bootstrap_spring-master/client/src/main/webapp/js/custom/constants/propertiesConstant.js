'use strict';

angular.module('app.constants').constant('propertiesConstant', {
    API_URL: '/api'
});