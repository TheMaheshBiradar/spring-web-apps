CREATE TABLE USER(ID INTEGER IDENTITY, NAME VARCHAR(5),EMAIL  VARCHAR(50),PHONE VARCHAR(40),DESCRIPTION VARCHAR(35));

insert into USER values('1', 'Hari','hari.ns.krishna@gmail.com','1234567890','Hi');
insert into USER values('2', 'Koushik','koushik.sharma@gmail.com','0987654321','Hello');