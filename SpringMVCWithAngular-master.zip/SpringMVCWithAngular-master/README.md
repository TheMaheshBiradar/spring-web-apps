# SpringMVCWithAngular
Spring with Angular JS

Develpoing a Spring MVC intergrating with Angular for the first time.
