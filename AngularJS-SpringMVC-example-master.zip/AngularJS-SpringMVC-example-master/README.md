AngularJS-SpringMVC-example
===========================

Ein Beispielprojekt für das Zusammenspiel von AngularJS und Spring-MVC.

Folgende Features werden gezeigt:
- Basiskonfiguration Spring MVC / AngularJS
- Einfache CRUD Funktionalität
- Generische Behandlung von (Fehler-)Meldungen
- Clientseitige I18N
- Security
- Javascript ohne globale Variablen